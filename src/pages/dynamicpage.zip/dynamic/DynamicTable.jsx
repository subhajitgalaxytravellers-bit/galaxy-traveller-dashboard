import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import api from "@/lib/api";
import DataTable from "@/components/DataTable";
import { Header } from "@/components/Header";
import {
  IconPhoto,
  IconCheck,
  IconX,
  IconFile,
  IconSearch,
} from "@tabler/icons-react";
import { debounce } from "lodash";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectItem,
  SelectContent,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import RequirePerm from "@/components/guard/RequirePerm";
import { usePermissions } from "@/hooks/use-permissions";
import { toast } from "react-toastify";
import useContentListInfinite from "@/hooks/useContentListInfinite";
/* ----------------------------- small utils ----------------------------- */
const fmtDate = (v) => {
  if (!v) return "—";
  const d = new Date(v);
  return isNaN(d) ? String(v) : d.toLocaleDateString();
};

const titleize = (s) =>
  s
    .replace(/\./g, " ")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replace(/_/g, " ")
    .replace(/\b\w/g, (m) => m.toUpperCase());

/* ------------------------------ API hooks ------------------------------ */
function useModelDef(modelKey) {
  return useQuery({
    queryKey: ["model-def", modelKey],
    queryFn: async () => (await api().get(`/api/schema/${modelKey}`)).data,
  });
}

const PathImgThumb = ({ pathOrUrl: src, alt }) => {
  return <ImgThumb src={src} alt={alt} />;
};

const PathImgPile = ({
  paths = [],
  limit = 4, // show up to this many tiles; last becomes +N if overflow
  alt,
  tilePx = 40, // matches h-10 w-10 (2.5rem)
  offsetPx = 10, // horizontal overlap offset between tiles
}) => {
  const arr = Array.isArray(paths) ? paths : [];
  const cap = Math.max(1, limit);

  const needsMore = arr.length > cap;
  const visible = needsMore ? arr.slice(0, cap - 1) : arr.slice(0, cap);
  const extra = arr.length - visible.length; // if needsMore, this is the +N
  const totalTiles = visible.length + (needsMore ? 1 : 0);

  const containerWidth = tilePx + Math.max(0, totalTiles - 1) * offsetPx;

  return (
    <div className="flex items-center" style={{ height: tilePx }}>
      <div
        className="relative"
        style={{ height: tilePx, width: containerWidth }}
      >
        {visible.map((p, i) => (
          <div
            key={i}
            className="absolute"
            style={{
              left: i * offsetPx,
              zIndex: i + 1,
              width: tilePx,
              height: tilePx,
            }}
            title={`${alt || "image"} ${i + 1}`}
          >
            {/* Uses your PathImgThumb -> ImgThumb (h-10 w-10 ring...) */}
            <PathImgThumb
              pathOrUrl={typeof p === "string" ? p : p?.path || p?.url || ""}
              alt={`${alt || "image"} ${i + 1}`}
            />
          </div>
        ))}

        {needsMore && (
          <div
            className="absolute flex items-center justify-center rounded-md ring-1 ring-gray-200 dark:ring-gray-700 bg-white dark:bg-gray-900 text-[11px] font-medium text-gray-700 dark:text-gray-200"
            style={{
              left: visible.length * offsetPx,
              zIndex: visible.length + 1,
              width: tilePx,
              height: tilePx,
            }}
            title={`+${extra} more`}
          >
            +{extra}
          </div>
        )}
      </div>
    </div>
  );
};

/* -------------------------- tiny cell components ----------------------- */
const BoolPill = ({ value }) => (
  <span
    className={[
      "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
      value
        ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300"
        : "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300",
    ].join(" ")}
  >
    {value ? (
      <IconCheck className="h-3.5 w-3.5" />
    ) : (
      <IconX className="h-3.5 w-3.5" />
    )}
    {value ? "Yes" : "No"}
  </span>
);

const StatusPill = ({ status }) => {
  const statusClasses = {
    draft:
      "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
    published:
      "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
    rejected: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
  };

  const iconClasses = {
    draft: <IconFile className="h-3.5 w-3.5" />,
    published: <IconCheck className="h-3.5 w-3.5" />,
    rejected: <IconX className="h-3.5 w-3.5" />,
  };

  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium transition-colors duration-300 ${
        statusClasses[status] || statusClasses.draft
      }`}
    >
      {iconClasses[status] || iconClasses.draft}
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
};

const ImgThumb = ({ src, alt }) =>
  src ? (
    <img
      src={src}
      alt={alt || "image"}
      loading="lazy" // ✅ native lazy load
      decoding="async" // ✅ speeds up rendering
      width={40} // ✅ avoids reflow (matches h-10)
      height={40}
      className="h-10 w-10 rounded-md object-cover ring-1 ring-gray-200 dark:ring-gray-700"
    />
  ) : (
    <span className="inline-flex h-10 w-10 items-center justify-center rounded-md ring-1 ring-gray-200 dark:ring-gray-700">
      <IconPhoto className="h-5 w-5 opacity-60" />
    </span>
  );

/* ---------------------- columns from schema + data --------------------- */
function buildColumns(modelDef, can) {
  if (!modelDef) return [];
  // console.log("buildColumns", modelDef);

  const schema = Array.isArray(modelDef.schema) ? modelDef.schema : [];
  const SKIP_TYPES = new Set(["relation", "relation[]", "object", "object[]"]);

  const cols = [];

  // ID first
  cols.push({
    key: "_id",
    label: "ID",
    thClass: "w-40",
    accessor: (r) => r._id || r.id || "—",
  });

  // Status column (custom)
  cols.push({
    key: "status",
    label: "Status",
    thClass: "w-32",
    cell: (r) => <StatusPill status={r.status || "draft"} />,
  });

  // Main fields
  schema.forEach((f) => {
    const { key, type, label } = f || {};
    if (!key) return;

    // Skip explicit status (we already inserted custom)
    if (key === "status") return;

    // Skip unwanted types entirely
    if (SKIP_TYPES.has(type)) return;
    // Skip the 'body' field
    if (key === "body") return;

    const nice = label || titleize(key);

    switch (type) {
      case "image":
        cols.push({
          key,
          label: nice,
          thClass: "w-24",
          cell: (r) => (
            <PathImgThumb pathOrUrl={r[key]} alt={r.title || r.name} />
          ),
        });
        break;

      case "image[]":
      case "images":
        cols.push({
          key,
          label: nice,
          thClass: "w-32",
          cell: (r) => (
            <PathImgPile paths={r[key]} limit={5} alt={r.title || r.name} />
          ),
        });
        break;

      case "switch":
      case "boolean":
        cols.push({
          key,
          label: nice,
          thClass: "w-28",
          cell: (r) => <BoolPill value={!!r[key]} />,
        });
        break;

      case "date":
        cols.push({
          key,
          label: nice,
          thClass: "w-36",
          accessor: (r) => fmtDate(r[key]),
        });
        break;

      case "number":
        cols.push({
          key,
          label: nice,
          thClass: "w-28",
          accessor: (r) => r[key] ?? "—",
        });
        break;

      case "textarea":
        cols.push({
          key,
          label: nice,
          thClass: "min-w-[220px]",
          accessor: (r) => r[key] || "—",
        });
        break;

      default:
        // Any other primitive-ish value
        cols.push({
          key,
          label: nice,
          thClass: "min-w-[140px]",
          accessor: (r) => r[key] ?? "—",
        });
        break;
    }
  });

  // Created/Updated
  cols.push({
    key: "createdAt",
    label: "Created",
    thClass: "w-36",
    accessor: (r) => fmtDate(r.createdAt),
  });
  cols.push({
    key: "updatedAt",
    label: "Updated",
    thClass: "w-36",
    accessor: (r) => fmtDate(r.updatedAt),
  });

  // Actions

  if (can(modelDef.key, "update") || can(modelDef.key, "delete")) {
    cols.push({
      key: "__actions",
      label: "Actions",
      thClass: "w-28",
    });
  }

  return cols;
}

/* --------------------------------- Page -------------------------------- */
export default function DynamicTable() {
  const { modelKey } = useParams();
  const { can } = usePermissions();

  const navigate = useNavigate();
  const queryClient = useQueryClient(); // ⬅️
  const [searchQuery, setSearchQuery] = useState("");
  const [tempSearch, setTempSearch] = useState("");

  const [selectedStatus, setSelectedStatus] = useState("all");

  // Debounce the search input to prevent frequent re-renders
  const debouncedSearch = debounce((value) => {
    setSearchQuery(value);
  }, 200); // Lower debounce delay to 200ms for faster response
  // Handle changes to search query and status
  const handleSearchChange = (e) => {
    const value = e.target.value;
    setTempSearch(value); // Update the immediate input value (for user feedback)
    debouncedSearch(value); // Apply debounced search
  };
  const {
    data: modelDef,
    isLoading: loadingDef,
    isError: errDef,
  } = useModelDef(modelKey);

  const {
    data: pages,
    isLoading,
    isError,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
  } = useContentListInfinite(modelKey, searchQuery, selectedStatus);

  const items = pages?.pages.flatMap((p) => p.items || []) || [];

  // console.log("items", items);
  const columns = React.useMemo(
    () => buildColumns(modelDef, can),
    [modelDef, items]
  );

  const loading = loadingDef || isLoading;
  const title = modelDef?.meta?.title || modelDef?.key || modelKey;

  useEffect(() => {
    // Whenever selectedStatus changes, fetch data with the selected status
    if (selectedStatus === "all") {
      // Fetch all data if filter is 'all'
      setSearchQuery(""); // Reset search query when switching to 'all' filter
    }
  }, [selectedStatus]);
  // ⬇️ optimistic delete handler
  const handleDelete = async (row) => {
    const id = row._id || row.id;

    // 1) optimistic update: drop from cache immediately
    const key = ["content-list", modelKey];
    // const prev = queryClient.getQueryData(key);

    queryClient.setQueryData(key, (old) => {
      if (!old) return old;
      const nextItems = (old.items || []).filter(
        (it) => (it._id || it.id) !== id
      );
      return {
        ...old,
        items: nextItems,
        total: Math.max(0, (old.total || nextItems.length) - 1),
      };
    });

    try {
      // 2) server delete
      await api().delete(`/api/${modelKey}/moderation/${id}`);
      // (optional) ensure cache is fresh for other tabs/filters:
      await queryClient.invalidateQueries({ queryKey: key });
    } catch (e) {
      console.error(e);
      // 3) rollback on error: refetch the list
      queryClient.invalidateQueries({ queryKey: key });
      toast.error("Failed to delete.");
    }
  };

  // ⬇️ duplicate handler
  const handleDuplicate = async (row) => {
    const id = row._id || row.id;
    try {
      await api().post(`/api/${modelKey}/moderation/${id}/duplicate`);
      toast.success("Item duplicated successfully.");
      // refresh the table data
      await queryClient.invalidateQueries({
        queryKey: ["content-list", modelKey],
      });
    } catch (e) {
      console.error(e);
      toast.error("Failed to duplicate item.");
    }
  };

  return (
    <div className="w-full min-h-screen flex flex-col">
      <RequirePerm
        model={modelKey}
        action="read"
        fallback={<div>You don't have access</div>}
      >
        <Header
          modelKey={modelKey}
          title={title}
          onCreate={() => navigate(`/content/${modelKey}/create`)}
        />
        <div className="p-4 md:p-6">
          {errDef ? (
            <div className="rounded-md border border-red-300 bg-red-50 p-4 text-red-700 dark:border-red-900/50 dark:bg-red-900/20 dark:text-red-200">
              Failed to load model definition for <b>{modelKey}</b>.
            </div>
          ) : isError ? (
            <div className="rounded-md border border-red-300 bg-red-50 p-4 text-red-700 dark:border-red-900/50 dark:bg-red-900/20 dark:text-red-200">
              Failed to load data for <b>{modelKey}</b>.
            </div>
          ) : (
            <DataTable
              model={modelKey}
              title={title}
              data={items}
              columns={columns}
              storageKey={`table:${modelKey}`}
              maxBodyHeight="75dvh"
              onEdit={(row) =>
                navigate(`/content/${modelKey}/${row._id || row.id}`)
              }
              loading={loading && !isFetchingNextPage}
              onDelete={handleDelete} // ⬅️ use the optimistic handler
              onDuplicate={handleDuplicate}
              rightActions={
                <div className="flex flex-wrap md:flex-nowrap justify-between w-[8rem] gap-4">
                  <div className="w-full min-w-[5rem] ">
                    <Select
                      value={selectedStatus}
                      onValueChange={setSelectedStatus} // Directly set the selected value
                      className="w-full px-4 py-1.5 border border-gray-300 rounded-md:border-gray-700 dark:border-gray-600"
                    >
                      <SelectTrigger className="w-full px-4 py-2 border border-gray-300 rounded-md  outline-none ring-0 dark:border-gray-700">
                        <SelectValue placeholder="All Status" />
                      </SelectTrigger>
                      <SelectContent
                        className={
                          "  border border-gray-300 rounded-md  outline-none ring-0 dark:border-gray-700"
                        }
                      >
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="published">Published</SelectItem>
                        <SelectItem value="rejected">Rejected</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              }
              leftActions={
                <div className="flex flex-wrap md:flex-nowrap justify-between w-[20rem] gap-4">
                  <div className="relative w-full min-w-[20rem]">
                    <IconSearch className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 opacity-60" />
                    <Input
                      value={tempSearch}
                      onChange={handleSearchChange}
                      placeholder="Search..."
                      className="pl-8 w-full outline-none ring-0"
                    />
                  </div>
                </div>
              }
              onLoadMore={fetchNextPage} // ⬅️ new
              hasNextPage={hasNextPage} // ⬅️ new
              isFetchingNextPage={isFetchingNextPage} // ⬅️ new
            />
          )}
        </div>
      </RequirePerm>
    </div>
  );
}
