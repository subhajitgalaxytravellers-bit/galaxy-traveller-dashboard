import { Switch } from "../ui/switch";

export default function SwitchField({ checked, onChange, label }) {
  return (
    <div className="flex items-center gap-3">
      <Switch checked={checked} onCheckedChange={onChange} />
      <span className="text-sm text-gray-700 dark:text-gray-300">{label}</span>
    </div>
  );
}
